import { LightningElement } from 'lwc';
import CQSync from '@salesforce/apex/CQPartCallout.syncPart';
import { ShowToastEvent } from "lightning/platformShowToastEvent";

export default class SyncData extends LightningElement {


    handleClick(event){
        event.preventDefault();
        CQSync()
        .then(result=>{
            this.showNotification('Sync Data',result,'success')
        })
        .catch(error=>{
            this.showNotification('Sync Data','Failed to Sync','error')
        })
    }
    showNotification(title,message,varient) {
        const evt = new ShowToastEvent({
          title: title,
          message: message,
          variant: varient,
        });
        this.dispatchEvent(evt);
      }
}